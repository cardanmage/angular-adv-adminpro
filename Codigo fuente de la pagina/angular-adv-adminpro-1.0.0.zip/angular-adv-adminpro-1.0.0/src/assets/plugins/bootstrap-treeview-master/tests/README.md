# Testing

Tests are run using [QUnit](https://qunitjs.com/) and [PhantomJS](http://phantomjs.org/)

To run the tests yourself.

```javascript
$ npm install
$ npm test
```

To view the test report.

```javascript
$ npm install
$ npm start
```

Then open a browser and navigate to [http://localhost:3000/tests.html](http://localhost:3000/tests.html)
